import React from 'react'
import noVideo from './noVideoFound.jpg'

const NoResult = () => {
  return (
    
    
    <img src={noVideo} alt='no video found'></img>
    
    
  )
}

export default NoResult