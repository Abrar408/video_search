const videoData = [
    {   id:'1',
        title : 'C# Application - How to make a WhatsApp Messenger | FoxLearn',
        views : '143k',
        channel : 'Learn to code'
    },
    {
        id:'2',
        title : 'Faisal Movers Bus Kaisi Hai? | Complete Guide | Karachi to Islamabad | Rapid Fire Kitchen',
        views : '1.1M',
        channel : 'PK buses'
    },
    {
        id:'3',
        title : 'Is coding really dead? 6 trends that look bad',
        views : '4.5k',
        channel : 'Code Ninja'
    },
    {
        id:'4',
        title : '7 Cryptography Concepts EVERY Developer Should Know',
        views : '900k',
        channel : 'Jxz'
    },
    {
        id:'5',
        title : 'Is Web3 all Hype? Top 10 Web 3.0 Questions & Answers',
        views : '9M',
        channel : 'Web 3.0'
    },
    {
        id:'6',
        title : '$3 Trillion Lithium Found in J&K | Geopolitics of Natural Resources | Dhruv Rathee',
        views : '100k',
        channel : 'Dhruv Rathee'
    },
    {
        id:'7',
        title : 'Karachi, Al-Qaida & Terrorism FT. Ali K. Chishti | Podcast #25',
        views : '367k',
        channel : 'Karachi vynz'
    },
    {
        id:'8',
        title : 'React JS Full Course 2022 | Build an App and Master React in 1 Hour',
        views : '24k',
        channel : 'Web dev'
    },
    {
        id:'9',
        title : 'Saudis in Audis',
        views : '11M',
        channel : 'SD'
    },
    {
        id:'10',
        title : 'THIS is how you Get RICH in your 20s.',
        views : '237k',
        channel : 'Lamo'
    },
    {
        id:'11',
        title : 'Closing a POWER ARC Switch with a WEAK ARC (LATITY-012)',
        views : '3.7M',
        channel : 'Rectifier'
    }
]
export default videoData